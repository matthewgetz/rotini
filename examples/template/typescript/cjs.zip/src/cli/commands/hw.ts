import { Command, } from 'rotini';

export const hw: Command = {
  name: 'hw',
  description: 'hello world',
};
