import { GlobalFlag, } from 'rotini';

export const global_flags: GlobalFlag[] = [];
