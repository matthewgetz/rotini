import { PositionalFlag, } from 'rotini';

export const positional_flags: PositionalFlag[] = [];
