import { Command, } from 'rotini';

import { hw, } from './hw.js';

export const commands: Command[] = [
  hw,
];
