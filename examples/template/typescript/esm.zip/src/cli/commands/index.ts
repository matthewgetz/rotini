import { Command, } from 'rotini';

import { hw, } from './hw';

export const commands: Command[] = [
  hw,
];
