const global_flags = [];

module.exports = {
  global_flags,
};
