const { hw, } = require('./hw');

const commands = [
  hw,
];

module.exports = {
  commands,
};
