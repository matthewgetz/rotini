const hw = {
  name: 'hw',
  description: 'hello world',
};

module.exports = {
  hw,
}
