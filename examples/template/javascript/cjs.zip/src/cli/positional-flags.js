const positional_flags = [];

module.exports = {
  positional_flags,
};
