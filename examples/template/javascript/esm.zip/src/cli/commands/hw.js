export const hw = {
  name: 'hw',
  description: 'hello world',
};
