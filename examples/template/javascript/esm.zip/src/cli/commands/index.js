import { hw, } from './hw.js';

export const commands = [
  hw,
];
