export const global_flags = [];

